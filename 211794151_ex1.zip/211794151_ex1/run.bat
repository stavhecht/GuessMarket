@echo off
chcp 65001 >nul
java -jar UI.jar
pause