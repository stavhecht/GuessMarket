@echo off
java -jar UI.jar
pause